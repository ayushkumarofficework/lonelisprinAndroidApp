package lonelisprin.lonelisprin;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;


public class ChatBox extends ActionBarActivity {
    ListView messageslist;
    List<Messages> convomessagesLinkedList=new ArrayList<>();
    EditText message;

    final Handler handler=new Handler();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d("weawe","on create chatbox");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_box);
        messageslist=(ListView)findViewById(R.id.messageslist);
        message=(EditText)findViewById(R.id.message);
        Button send=(Button)findViewById(R.id.sendmessagebutton);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!message.getText().toString().equals("")){
                    convomessagesLinkedList.add(new Messages(MainActivity.session_pair_id,MainActivity.session_user_id,message.getText().toString()));
                    populateLeftConvoMessages();
                    sendMessage(message.getText().toString());
                    messageslist.setSelection(convomessagesLinkedList.size());
                    message.setText("");
                }
            }
        });

        final Runnable messagesListRunnable=new Runnable() {
            @Override
            public void run() {
                new GetNewMessages().execute(new ApiConnector());
                handler.postDelayed(this,3000);
            }
        };
        handler.post(messagesListRunnable);
        new GetMessages().execute(new ApiConnector());


    }

    public void sendMessage(final String message){
        class SendMessageAsyncTask extends AsyncTask<String,Short,JSONArray>{

            @Override
            protected JSONArray doInBackground(String... params) {
                String output;
                JSONArray jsonArray=null;
                Log.d("weawe","message background");
                String url= "http://"+MainActivity.url+"/lonelisprin/android/sendmessage.php";
                HttpClient httpClient = new DefaultHttpClient();
                HttpPost httpPost = new HttpPost(url);
                ArrayList<NameValuePair> param = new ArrayList<>();
                param.add(new BasicNameValuePair("message", params[0]));
                param.add(new BasicNameValuePair("sender_id", MainActivity.session_user_id));
                param.add(new BasicNameValuePair("pair_id",MainActivity.session_pair_id));
                try {
                    //String output;
                    Log.d("weawe","trying to insert message");
                    httpPost.setEntity(new UrlEncodedFormEntity(param));
                    HttpResponse httpRespose = httpClient.execute(httpPost);
                    HttpEntity httpEntity = httpRespose.getEntity();
                    InputStream in = httpEntity.getContent();
                    BufferedReader br = new BufferedReader(new InputStreamReader(in));

                    StringBuilder sb=new StringBuilder();
                    String line="";
                    while((line=br.readLine())!=null){
                        sb.append(line + "\n");

                    }
                    output =sb.toString();
                    Log.d("weawe", output);
                    jsonArray=new JSONArray(output);


                } catch (IOException | JSONException e) {
                    e.printStackTrace();
                }
                return jsonArray;
            }
            @Override
            protected void onPostExecute(JSONArray jsonArray){

            }
        }
        SendMessageAsyncTask sendMessageAsyncTask=new SendMessageAsyncTask();
        sendMessageAsyncTask.execute(message);
    }

    public void populateLeftConvoMessages(){
        ArrayAdapter<Messages> adapter= new ConvoMessagesListAdapter();
        Log.d("weawe","adapter called");
        messageslist.setAdapter(adapter);
    }
    class GetNewMessages extends AsyncTask<ApiConnector,Short,JSONArray>{

        @Override
        protected JSONArray doInBackground(ApiConnector... params) {
            return params[0].getNewMessages();
        }
        @Override
        protected void onPostExecute(JSONArray jsonArray){
            JSONObject json;
            try{
                for(int i=0;i<jsonArray.length();i++){
                    json=jsonArray.getJSONObject(i);
                    convomessagesLinkedList.add(new Messages(json.getString("pair_id"),json.getString("sender_id"),json.getString("message")));
                    Log.d("weawe", MainActivity.session_user_id);
                    Log.d("weawe", " "+( MainActivity.session_user_id.compareTo(json.getString("sender_id"))));


                    populateLeftConvoMessages();


                    Log.d("weawe","populate function called");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            messageslist.setSelection(convomessagesLinkedList.size());
        }
    }

    class GetMessages extends AsyncTask<ApiConnector,Short,JSONArray>{

        @Override
        protected JSONArray doInBackground(ApiConnector... params) {
            Log.d("weawe","message do in background");
            return params[0].getMessagesByPairId();
        }
        @Override
        protected void onPostExecute(JSONArray jsonArray){
            JSONObject json;
            try{
                for(int i=0;i<jsonArray.length();i++){
                    json=jsonArray.getJSONObject(i);
                    convomessagesLinkedList.add(new Messages(json.getString("pair_id"),json.getString("sender_id"),json.getString("message")));
                    Log.d("weawe", MainActivity.session_user_id);
                    Log.d("weawe", " "+( MainActivity.session_user_id.compareTo(json.getString("sender_id"))));


                        populateLeftConvoMessages();


                    Log.d("weawe","populate function called");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            messageslist.setSelection(convomessagesLinkedList.size());
        }
    }

    private class ConvoMessagesListAdapter extends ArrayAdapter<Messages> {
        public ConvoMessagesListAdapter(){

           super(ChatBox.this, R.layout.left_alligned_message, convomessagesLinkedList);
            Log.d("weawe","adapter constructed");
        }
        @Override
        public View getView(int position,View view,ViewGroup parent){


           if(view==null)
                view=getLayoutInflater().inflate(R.layout.left_alligned_message,parent,false);
            final Messages currentmessage=convomessagesLinkedList.get(position);

            if(currentmessage.get_sender_id().compareTo(MainActivity.session_user_id)==0){
                TextView rightmessage=(TextView)view.findViewById(R.id.rightmessage);
                TextView leftmessage=(TextView)view.findViewById(R.id.leftmessage);
                rightmessage.setText(currentmessage.get_message());
                leftmessage.setText("");
            }
            else{
                TextView leftmessage=(TextView)view.findViewById(R.id.leftmessage);
                TextView rightmessage=(TextView)view.findViewById(R.id.rightmessage);
                leftmessage.setText(currentmessage.get_message());
                rightmessage.setText("");
            }


            Log.d("weawe","message set");





            return view;
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_chat_box, menu);
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
       // handler.removeCallbacks(messageListRunnable);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
