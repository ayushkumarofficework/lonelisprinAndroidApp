package lonelisprin.lonelisprin;

/**
 * Created by HP-PC on 22-08-2016.
 */
public class MessageList {
    private String _name,_message,_id;
    long _timestamp;
    public MessageList(String name,String message,String id,long timestamp){
        _name=name;
        _message=message;
        _id=id;
        _timestamp=timestamp;
    }
    public String get_name(){
        return _name;
    }
    public long get_timestamp(){
        return _timestamp;
    }
    public String get_message(){
        return _message;
    }
    public String get_id(){
        return _id;
    }
}
