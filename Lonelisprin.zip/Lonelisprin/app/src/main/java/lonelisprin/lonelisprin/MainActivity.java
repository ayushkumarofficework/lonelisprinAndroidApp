package lonelisprin.lonelisprin;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends ActionBarActivity {
    public static String session_user_id;
    public static String session_username;
    public static String session_useremail;
    public static String session_reciever_user_id;
    public static  String session_pair_id;
    public static String url="10.0.2.2";
    List<PeopleList> peoplelinkedlist =new ArrayList<>();
    List<MessageList> messagelinkedlist=new ArrayList<>();
    ListView peopleList;
    ListView messageListView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //final String session_userid;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TabHost tabhost=(TabHost)findViewById(R.id.tabHost);
        tabhost.setup();
        TabHost.TabSpec tabspec=tabhost.newTabSpec("messages");
        tabspec.setIndicator("messages");
        tabspec.setContent(R.id.messages);
        tabhost.addTab(tabspec);

        tabspec=tabhost.newTabSpec("people");
        tabspec.setIndicator("people");
        tabspec.setContent(R.id.people);
        tabhost.addTab(tabspec);

        tabspec=tabhost.newTabSpec("tab3");
        tabspec.setIndicator("tab3");
        tabspec.setContent(R.id.tab3);
        tabhost.addTab(tabspec);
        DatabaseHelper databaseHandler=new DatabaseHelper(getApplicationContext());
        boolean session=databaseHandler.searchSession("true");
        if(session){
            Intent i=new Intent(getApplicationContext(),register.class);
            startActivity(i);
        }
        else{
            databaseHandler.sessionuseron("true");
            final Handler handler = new Handler();
            final Runnable updateTimestampRunnable = new Runnable()
            {
                public void run()
                {
                    // code here what ever is required
                    new UpdateTimestamp().execute(new ApiConnector());
                    handler.postDelayed(this,15000);
                }
            };
            handler.post(updateTimestampRunnable);


            final Runnable getPeopleListRunnable=new Runnable() {
                @Override
                public void run() {
                    new GetPeopleList().execute(new ApiConnector());
                    handler.postDelayed(this,15000);
                }
            };
            handler.post(getPeopleListRunnable);
            final Runnable getMessageListRunnable=new Runnable() {
                @Override
                public void run() {
                    new GetMessageList().execute(new ApiConnector());
                    handler.postDelayed(this,15000);
                }
            };
            handler.post(getMessageListRunnable);
        }
        Toast.makeText(getApplicationContext(),session_username+" "+session_useremail,Toast.LENGTH_SHORT).show();


        peopleList=(ListView)findViewById(R.id.peoplelistview);
        messageListView=(ListView)findViewById(R.id.messagelistview);
        messageListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                MessageList tempMessage=messagelinkedlist.get(position);
                session_reciever_user_id=tempMessage.get_id();
                new GetPairId().execute(new ApiConnector());
            }
        });
        peopleList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                PeopleList tempPerson=peoplelinkedlist.get(position);
                session_reciever_user_id=tempPerson.getUserid();
                new GetPairId().execute(new ApiConnector());
            }
        });
    }
    public void populate(){
        ArrayAdapter<PeopleList> adapter=new PeopleListAdapter();
        peopleList.setAdapter(adapter);
    }
    public void populateMessagelist(){
        ArrayAdapter<MessageList> adapter=new MessageListAdapter();
        messageListView.setAdapter(adapter);
    }
    class UpdateTimestamp extends AsyncTask<ApiConnector,Short,JSONArray>{

        @Override
        protected JSONArray doInBackground(ApiConnector... params) {
            return params[0].updateTimestamp(MainActivity.session_user_id);
        }
    }

        class GetPairId extends AsyncTask<ApiConnector,Short,JSONArray>{

            @Override
            protected JSONArray doInBackground(ApiConnector... params) {
                return params[0].getPairId();

            }
            @Override
            protected void onPostExecute(JSONArray jsonArray){
                Log.d("weawe","pairid retrieved");
                for(int i=0;i<jsonArray.length();i++){
                    JSONObject json;
                    try{
                        json=jsonArray.getJSONObject(i);
                        MainActivity.session_pair_id=json.getString("pair_id");
                        Log.d("weawe","session variable set");
                        Intent in=new Intent(getApplicationContext(),ChatBox.class);
                        Log.d("weawe","intent specified");

                        startActivity(in);
                        Log.d("weawe","intent called");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

        }

    class GetMessageList extends AsyncTask<ApiConnector,Short,JSONArray>{

        @Override
        protected JSONArray doInBackground(ApiConnector... params) {

            return params[0].getMessageList(session_user_id);
        }
        @Override
        protected void onPostExecute(JSONArray jsonArray){
            messagelinkedlist.clear();
            for(int i=0;i<jsonArray.length();i++){
                JSONObject json;
                try{
                    json=jsonArray.getJSONObject(i);
                    messagelinkedlist.add(new MessageList(json.getString("name"),json.getString("message"),json.getString("id"),json.getLong("time")));
                    populateMessagelist();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

        class GetPeopleList extends AsyncTask<ApiConnector,Short,JSONArray>{


            @Override
            protected JSONArray doInBackground(ApiConnector... params) {

                return params[0].getPeopleList(session_user_id);
            }

            @Override
            protected  void onPostExecute(JSONArray jsonArray){
                peoplelinkedlist.clear();
                for(int i=0;i<jsonArray.length();i++){
                    JSONObject json;
                    try{
                        json=jsonArray.getJSONObject(i);///correct this line
                        peoplelinkedlist.add( new PeopleList(json.getString("name"), json.getString("email"), json.getString("id"), json.getLong("lastseen")));
                        populate();
                        //Log.d("weawe","session is active");

                    } catch (JSONException e) {

                        e.printStackTrace();
                    }
                }
            }
        }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    private class PeopleListAdapter extends ArrayAdapter<PeopleList> {
        public PeopleListAdapter(){
            super(MainActivity.this,R.layout.people_list_layout,peoplelinkedlist);
        }
        @Override
        public View getView(int position,View view,ViewGroup parent){


            if(view==null)
                view=getLayoutInflater().inflate(R.layout.people_list_layout,parent,false);

            final PeopleList currentperson=peoplelinkedlist.get(position);


            TextView person=(TextView)view.findViewById(R.id.personname);
            person.setText(currentperson.getUsername());
            TextView status=(TextView)view.findViewById(R.id.status);
            long timeMillis = System.currentTimeMillis()/1000;
           // long timeSeconds =  TimeUnit.MILLISECONDS.toSeconds(timeMillis);
            //Long presentTime= System.currentTimeMillis()/1000;
            //Toast.makeText(getApplicationContext(), "hi "+timeMillis,Toast.LENGTH_SHORT).show();
            if(timeMillis-currentperson.getTimestamp()<30){

                status.setText("    "+"Online");
            }
            else{
                status.setText(" "+
                        "Offline");
            }

            //des.setText(currentperson.getDescription());





            return view;
        }

    }
    private class MessageListAdapter extends ArrayAdapter<MessageList>{

    public MessageListAdapter(){
        super(MainActivity.this,R.layout.message_item_layout,messagelinkedlist);
    }
        @Override
        public View getView(int position,View view,ViewGroup parent){


            if(view==null)
                view=getLayoutInflater().inflate(R.layout.message_item_layout,parent,false);

            final MessageList currentmessage=messagelinkedlist.get(position);


            TextView person=(TextView)view.findViewById(R.id.sender);
            person.setText(currentmessage.get_name());
            TextView message=(TextView)view.findViewById(R.id.message);
            message.setText(currentmessage.get_message());
            TextView timedate=(TextView)view.findViewById(R.id.timedate);

            //

            timedate.setText("time date");
            //TextView status=(TextView)view.findViewById(R.id.status);
            //long timeMillis = System.currentTimeMillis()/1000;
            // long timeSeconds =  TimeUnit.MILLISECONDS.toSeconds(timeMillis);
            //Long presentTime= System.currentTimeMillis()/1000;
           // Toast.makeText(getApplicationContext(), "hi "+timeMillis,Toast.LENGTH_SHORT).show();


            //des.setText(currentperson.getDescription());





            return view;
        }

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

}
