package lonelisprin.lonelisprin;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by HP-PC on 17-08-2016.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final int database_version=1;
    private static final String database_name="lonelisprin",table_user="lonelyusers",user_id="id",nameofuser="name",username="email",session="session",passwordofuser="password";
    public DatabaseHelper(Context context){
        super(context,database_name,null,database_version);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE "+ table_user+" ("+user_id+" INTEGER PRIMARY KEY NOT NULL,"+nameofuser+" TEXT NOT NULL,"+username+" TEXT NOT NULL,"+passwordofuser+" TEXT NOT NULL,"+session+" BOOLEAN NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+table_user);
    }
    public void insertUser(String name,String email,String password,String id){
        SQLiteDatabase db= this.getWritableDatabase();
        String query="SELECT * FROM "+table_user;
        Cursor cursor=db.rawQuery(query,null);
        //int count=cursor.getCount();
        cursor.close();
        ContentValues values=new ContentValues();
        values.put(user_id,id);
        values.put(nameofuser,name);
        values.put(username,email);
        values.put(passwordofuser,password);
        values.put(session,"true");
       MainActivity.session_user_id=id;
        MainActivity.session_username=name;
        MainActivity.session_useremail=email;
        db.insert(table_user,null,values);
        Log.d("weawe", "user inserted in the database");
        db.close();
    }
    public boolean searchSession(String b){
        SQLiteDatabase db=this.getReadableDatabase();


        Cursor cursor=db.query(table_user,new String[]{user_id,nameofuser,username,passwordofuser},session +"=?",new String[]{b},null,null,null,null);
        if(!cursor.moveToFirst())
        {   db.close();
            Log.d("weawe","searching session nothing is found ");
            return true;

        }
        else{db.close();

            int count=cursor.getCount();
            Log.d("weawe","searching session and session is found "+count);
            Log.d("weawe","number of session active ");
            cursor.close();
            return false;}
    }
    public void loginUser(String id, String name, String email, String password){
        SQLiteDatabase db= this.getWritableDatabase();

        db.delete(table_user,null,null);
        Log.d("weawe","database deleted");
        ContentValues values=new ContentValues();
        values.put(user_id,id);
        values.put(nameofuser,name);
        values.put(username,email);
        values.put(passwordofuser,password);
        values.put(session,"true");
        MainActivity.session_user_id=id;
        MainActivity.session_username=name;
        MainActivity.session_useremail=email;
        db.insert(table_user,null,values);
        Log.d("weawe", "user logged in");
        db.close();
    }
    public void sessionuseron(String b){
        Log.d("weawe","searching for user whose session is on");
        String session_user;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor=db.query(table_user,new String[]{user_id,nameofuser,username,passwordofuser,session},session +"=?",new String[]{b},null,null,null,null);
        if(!cursor.moveToFirst()){
            Log.d("weawe","searching for user whose session is on and session is not found");
            session_user="";
            db.close();


        }
        else
        {   Log.d("weawe","searching for user whose session is on and session is found");
            MainActivity.session_user_id=cursor.getString(0);
            MainActivity.session_username=cursor.getString(1);
            MainActivity.session_useremail=cursor.getString(2);
            db.close();
            cursor.close();

        }

    }
}
