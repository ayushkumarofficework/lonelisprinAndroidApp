package lonelisprin.lonelisprin;

/**
 * Created by HP-PC on 24-08-2016.
 */
public class Messages {
    private String _pair_id,_sender_id,_message;
    public Messages(String pair_id,String sender_id,String message){
        _message=message;

        _pair_id=pair_id;
        _sender_id=sender_id;
    }

    public String get_pair_id(){
        return _pair_id;
    }
    public String get_message(){
        return _message;
    }
    public String get_sender_id(){
        return _sender_id;
    }

}
