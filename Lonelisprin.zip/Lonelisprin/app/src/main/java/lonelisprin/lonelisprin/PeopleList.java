package lonelisprin.lonelisprin;

/**
 * Created by HP-PC on 20-08-2016.
 */
public class PeopleList {
    private String _username;
    private String _useremail;

    private String _userid;
    private Long _timestamp;

    public PeopleList(String username,String useremail,String userid,Long timestamp){
        _username=username;
        _userid=userid;
        _useremail=useremail;
        _timestamp=timestamp;
    }

    public String getUsername() {
        return _username;
    }

    public String getUseremail() {
        return _useremail;
    }
    public String getUserid(){
        return _userid;
    }
    public Long getTimestamp(){return _timestamp;}
}
