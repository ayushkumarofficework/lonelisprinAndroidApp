package lonelisprin.lonelisprin;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by HP-PC on 20-08-2016.
 */
public class ApiConnector {
    public JSONArray getPeopleList(String sessionuserid){
        JSONArray jsonArray = null;
        String output;
        try{
            String url="http://"+MainActivity.url+"/lonelisprin/android/getpeople.php?user_id=" + sessionuserid;
            URL obj=new URL(url);
            HttpURLConnection connection=(HttpURLConnection)obj.openConnection();
            BufferedReader br=new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder sb=new StringBuilder();
            String line="";
            while((line=br.readLine())!=null){
                sb.append(line + "\n");
                // sb.append(line).append("\n");
            }
            output =sb.toString();
            Log.d("weawe", output);
            jsonArray=new JSONArray(output);
        } catch (JSONException | IOException e) {
            e.printStackTrace();
        }
        return jsonArray;

    }
    public JSONArray getMessageList(String sessionuserid){
        JSONArray jsonArray=null;
        String output;
        try{
            String url="http://"+MainActivity.url+"/lonelisprin/android/getmessageupdated.php?user_id="+MainActivity.session_user_id;
            //TODO change url
            URL obj=new URL(url);
            HttpURLConnection connection=(HttpURLConnection)obj.openConnection();
            BufferedReader br=new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder sb=new StringBuilder();
            String line="";
            while((line=br.readLine())!=null){
                sb.append(line + "\n");
                // sb.append(line).append("\n");
            }
            output =sb.toString();
            Log.d("weawe", output);
            jsonArray=new JSONArray(output);
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        return jsonArray;
    }
    public JSONArray getPairId(){
        JSONArray jsonArray=null;
        String output;
        try{
            String url="http://"+MainActivity.url+"/lonelisprin/android/getpair.php?session_user_id="+MainActivity.session_user_id+"&user_id="+MainActivity.session_reciever_user_id;
            URL obj=new URL(url);
            HttpURLConnection connection=(HttpURLConnection)obj.openConnection();
            BufferedReader br=new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder sb=new StringBuilder();
            String line="";
            while((line=br.readLine())!=null){
                sb.append(line + "\n");
                // sb.append(line).append("\n");
            }
            output =sb.toString();
            Log.d("weawe", output);
            jsonArray=new JSONArray(output);
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        return jsonArray;
    }

    // update timestamp function
    public JSONArray updateTimestamp(String sessionUserId){
        JSONArray jsonArray=null;
        String output;
        try{
            String url="http://"+MainActivity.url+"/lonelisprin/android/updatetimestamp.php?user_id="+MainActivity.session_user_id;
            URL obj=new URL(url);
            HttpURLConnection connection=(HttpURLConnection)obj.openConnection();
            BufferedReader br=new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder sb=new StringBuilder();
            String line="";
            while((line=br.readLine())!=null){
                sb.append(line + "\n");
                // sb.append(line).append("\n");
            }
            output =sb.toString();
            Log.d("weawe", output);
            jsonArray=new JSONArray(output);
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        return jsonArray;
    }

    //getting new messages
    public JSONArray getNewMessages(){
        JSONArray jsonArray=null;
        String output;
        try{
            String url="http://"+MainActivity.url+"/lonelisprin/android/getnewmessages.php?pair_id="+MainActivity.session_pair_id+"&user_id="+MainActivity.session_user_id;
            URL obj=new URL(url);
            HttpURLConnection connection=(HttpURLConnection)obj.openConnection();
            BufferedReader br=new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder sb=new StringBuilder();
            String line="";
            while((line=br.readLine())!=null){
                sb.append(line + "\n");
                // sb.append(line).append("\n");
            }
            output =sb.toString();
            Log.d("weawe", output);
            jsonArray=new JSONArray(output);
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        return jsonArray;
    }

    public JSONArray getMessagesByPairId() {
        JSONArray jsonArray=null;
        String output;
        try{
            String url="http://"+MainActivity.url+"/lonelisprin/android/getmessages.php?pair_id="+MainActivity.session_pair_id+"&user_id="+MainActivity.session_user_id;
            URL obj=new URL(url);
            HttpURLConnection connection=(HttpURLConnection)obj.openConnection();
            BufferedReader br=new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder sb=new StringBuilder();
            String line="";
            while((line=br.readLine())!=null){
                sb.append(line + "\n");
                // sb.append(line).append("\n");
            }
            output =sb.toString();
            Log.d("weawe", output);
            jsonArray=new JSONArray(output);
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        return jsonArray;

    }
}
