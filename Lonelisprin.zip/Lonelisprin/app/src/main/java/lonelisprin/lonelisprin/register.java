package lonelisprin.lonelisprin;

import android.annotation.TargetApi;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


public class register extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        final EditText loginEmail = (EditText) findViewById(R.id.loginemail);
        final EditText loginpassword = (EditText) findViewById(R.id.loginpassword);
        final EditText registeremail = (EditText) findViewById(R.id.registeremail);
        final EditText registername = (EditText) findViewById(R.id.registername);
        final EditText registerpassword = (EditText) findViewById(R.id.registerpassword);
        Button registerbutton = (Button) findViewById(R.id.registerbutton);
        Button loginbutton = (Button) findViewById(R.id.loginbutton);
        loginbutton.setOnClickListener(new View.OnClickListener() {
            @TargetApi(Build.VERSION_CODES.GINGERBREAD)
            @Override
            public void onClick(View v) {
                if (loginEmail.getText().toString().trim().isEmpty() || loginpassword.getText().toString().trim().isEmpty()) {
                    loginEmail.setText("");
                    loginpassword.setText("");
                    Toast.makeText(getApplicationContext(), "Fill all the data", Toast.LENGTH_SHORT).show();
                } else {
                        //login function called to activate session
                        loginuser(loginEmail.getText().toString().trim(),loginpassword.getText().toString().trim());
                }
            }
        });
        registerbutton.setOnClickListener(new View.OnClickListener() {
            @TargetApi(Build.VERSION_CODES.GINGERBREAD)
            @Override
            public void onClick(View v) {
                //String output;
                if (registeremail.getText().toString().trim().isEmpty() || registername.getText().toString().trim().isEmpty() || registerpassword.getText().toString().trim().isEmpty()) {
                    registeremail.setText("");
                    registername.setText("");
                    registerpassword.setText("");
                } else {
                    insertUserIntoDb(registername.getText().toString().trim(), registeremail.getText().toString().trim(), registerpassword.getText().toString().trim());

                    Log.d("weawe", "name value pair forming");

                }
            }
        });
    }
    public void loginuser(final String loginemail, final String loginpassword){
        Log.d("weawe","login function called");
        class LoginIntoServer extends AsyncTask<String,Short,JSONArray>{
            String output;
            @Override
            protected JSONArray doInBackground(String... params) {
                Log.d("weawe", "doin background of login called");

                String emailofuser = loginemail;
                String passwordofuser = loginpassword;
                //nameofuser = nameofuser.replace(" ", "_");
                emailofuser = emailofuser.replace(" ", "_");
                passwordofuser = passwordofuser.replace(" ", "_");
                Log.d("weawe","requesting server");
                JSONArray jsonArray = null;
                try{
                    String url="http://"+MainActivity.url+"/lonelisprin/android/loginuser.php?email=" + emailofuser + "&password=" + passwordofuser;
                    URL obj=new URL(url);
                    HttpURLConnection connection=(HttpURLConnection)obj.openConnection();
                    BufferedReader br=new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder sb=new StringBuilder();
                    String line="";
                    while((line=br.readLine())!=null){
                        sb.append(line + "\n");
                        // sb.append(line).append("\n");
                    }
                    output =sb.toString();
                    Log.d("weawe",output);
                    try{
                        jsonArray=new JSONArray(output);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

                return jsonArray;
            }

            @Override
            protected void onPostExecute(JSONArray jsonarray){
                for(int i=0;i<jsonarray.length();i++){
                    JSONObject json;
                    try{
                        json=jsonarray.getJSONObject(i);///correct this line
                        DatabaseHelper helper=new DatabaseHelper(getApplicationContext());
                        helper.loginUser(json.getString("id"),json.getString("name"),json.getString("email"),json.getString("password"));
                        Log.d("weawe","user logged in successfully");
                        Intent in=new Intent(getApplicationContext(),MainActivity.class);
                        startActivity(in);
                    } catch (JSONException e) {

                        e.printStackTrace();
                    }
                }
            }
        }
        LoginIntoServer loginobject=new LoginIntoServer();
        loginobject.execute(loginemail,loginpassword);
    }

    public void insertUserIntoDb(final String name, final String email, final String password) {
        Log.d("weawe", "inset into database function called");
        class SendDataIntoDatabase extends AsyncTask<String, Short, JSONArray> {
            String output;

            @Override
            protected JSONArray doInBackground(String... params) {
                Log.d("weawe", "doin background called");
                String nameofuser = name;
                String emailofuser = email;
                String passwordofuser = password;
                nameofuser = nameofuser.replace(" ", "_");
                emailofuser = emailofuser.replace(" ", "_");
                passwordofuser = passwordofuser.replace(" ", "_");

                Log.d("weawe", "post request sent");
                try {
                    //String url = "http://192.168.220.59/weawe/weaweinsertposts.php?post_user="+postuser+"&post_description="+postdescription+"&post_type=posted";
                    String url = "http://"+MainActivity.url+"/lonelisprin/android/insertuser.php?name=" + nameofuser + "&email=" + emailofuser + "&password=" + passwordofuser;
                    URL obj = new URL(url);
                    HttpURLConnection connection = (HttpURLConnection) obj.openConnection();
                    BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder sb=new StringBuilder();
                    String line="";
                    while((line=br.readLine())!=null){
                        sb.append(line + "\n");
                        // sb.append(line).append("\n");
                    }
                    output =sb.toString();
                   // String last[]=output.split("</font>");
                    //output=last[1];
                    Log.d("weawe",output);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                JSONArray jsonArray=new JSONArray();
                try {
                    jsonArray= new JSONArray(output);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return jsonArray;
            }
            @Override
            protected void onPostExecute(JSONArray jsonArray){
                //String temp="true";
                if(!jsonArray.toString().equals("")){

                    for(int i=0;i<jsonArray.length();i++){
                        JSONObject json;
                        try{
                            json=jsonArray.getJSONObject(i);///correct this line
                            DatabaseHelper databaseHelper=new DatabaseHelper(getApplicationContext());
                            databaseHelper.insertUser(name,email,password,json.getString("id"));
                            Log.d("weawe","session is active");
                            Intent in=new Intent(getApplicationContext(),MainActivity.class);
                            startActivity(in);
                        } catch (JSONException e) {

                            e.printStackTrace();
                        }
                    }
                }


                else{
                    Log.d("weawe",output);
                    Toast.makeText(getApplicationContext(),"Email id already exists!",Toast.LENGTH_SHORT).show();
                }
            }



        }
        SendDataIntoDatabase sendPostReqAsyncTask=new SendDataIntoDatabase();
        sendPostReqAsyncTask.execute(name,email,password);
    }













    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present..
        getMenuInflater().inflate(R.menu.menu_register, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
