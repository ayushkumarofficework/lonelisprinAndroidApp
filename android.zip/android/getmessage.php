<?php
	header('Content-type:application/json');
    $connection = mysqli_connect("localhost", "root" , "","lonelisprin");
	$userid=$_REQUEST['user_id'];
	$seen=";".$userid.";";
	$query1="SELECT * FROM lonelyusers WHERE id IN (SELECT DISTINCT(sender_id) FROM lonelymessages WHERE seen NOT LIKE '%".$seen."%' AND pair_id IN (SELECT pair_id FROM lonelypairs WHERE (first_user_id='".$userid."') OR (second_user_id='".$userid."'))) AND id <>'".$userid."' ";
	$result1=mysqli_query($connection,$query1);
	$rows=array();
		while($row=mysqli_fetch_assoc($result1))
			{
				$rows[]=$row;
				$rows[]['new']="true";
			}
	$query2="SELECT * FROM lonelyusers WHERE id IN (SELECT DISTINCT(sender_id) FROM lonelymessages WHERE seen LIKE '%".$seen."%' AND pair_id IN (SELECT pair_id FROM lonelypairs WHERE (first_user_id='".$userid."') OR (second_user_id='".$userid."'))) AND id <>'".$userid."' AND id NOT IN (SELECT id FROM lonelyusers WHERE id IN (SELECT DISTINCT(sender_id) FROM lonelymessages WHERE seen NOT LIKE '%".$seen."%' AND pair_id IN (SELECT pair_id FROM lonelypairs WHERE (first_user_id='".$userid."') OR (second_user_id='".$userid."'))) AND id <>'".$userid."' )";
	$result2=mysqli_query($connection,$query2);
	while($row=mysqli_fetch_assoc($result2)){
		$rows[]=$row;
		$rows[]['new']="false";
	}
	echo json_encode($rows);