<?php 
    header('Content-type:application/json');
    $connection = mysqli_connect("localhost", "root" , "","lonelisprin");
	$userid=$_REQUEST['user_id'];
	$query="SELECT id,name,email,lastseen FROM lonelyusers WHERE id!='".$userid."'";
	$result=mysqli_query($connection,$query);
	$rows=array();
		while($row=mysqli_fetch_assoc($result))
			{
				$rows[]=$row;
			}
			echo json_encode($rows);
?>