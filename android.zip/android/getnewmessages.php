<?php
	header('Content-type:application/json');
    $connection = mysqli_connect("localhost", "root" , "","lonelisprin");
	$userid=$_REQUEST['user_id'];
	$pairid=$_REQUEST['pair_id'];
	$seen=";".$userid.";";
	$query="SELECT * FROM lonelymessages WHERE pair_id='".$pairid."' AND seen NOT LIKE '%".$seen."%'";
	$result=mysqli_query($connection,$query);
	$rows=array();
		while($row=mysqli_fetch_assoc($result))
			{
				$rows[]=$row;
				if(strpos($row['seen'],$seen)===false){
				$seen=$seen.$row['seen'];
				$result_new=mysqli_query($connection,"UPDATE lonelymessages SET seen='".$seen."' WHERE message_id='".$row['message_id']."'");
				}
			}
	echo json_encode($rows);
?>