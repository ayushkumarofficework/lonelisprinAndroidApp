<?php
header('Content-type:application/json');
    $connection = mysqli_connect("localhost", "root" , "","lonelisprin");
	$userid=$_REQUEST['user_id'];
	
	$seen="%;".$userid.";%";
	$query1="SELECT * FROM lonelyusers,lonelymessages,lonelypairs WHERE lonelymessages.sender_id != '".$userid."' lonelyusers.id=lonelymessages.sender_id AND lonelymessages.message_id IN (SELECT DISTINCT(lonelymessages.message_id) FROM lonelymessages,lonelypairs WHERE lonelymessages.seen NOT LIKE '%".$seen."%' AND lonelymessages.pair_id IN (SELECT lonelypairs.pair_id FROM lonelypairs WHERE (lonelypairs.first_user_id='".$userid."') OR (lonelypairs.second_user_id='".$userid."')) ORDER BY lonelymessages.message_id DESC)";
	$query2="SELECT * FROM lonelyusers,lonelymessages,lonelypairs WHERE lonelymessages.sender_id != '".$userid."' lonelyusers.id=lonelymessages.sender_id AND lonelymessages.message_id IN (SELECT DISTINCT(lonelymessages.message_id) FROM lonelymessages,lonelypairs WHERE lonelymessages.seen LIKE '%".$seen."%' AND lonelymessages.pair_id IN (SELECT lonelypairs.pair_id FROM lonelypairs WHERE (lonelypairs.first_user_id='".$userid."') OR (lonelypairs.second_user_id='".$userid."')) ORDER BY lonelymessages.message_id DESC)";
	$q = "SELECT lu.id,lm.message_id,lm.message,lm.time,lu.name FROM lonelyusers as lu,(SELECT * FROM lonelymessages ORDER BY time DESC) as lm,lonelypairs as lp WHERE (lp.first_user_id=$userid OR lp.second_user_id=$userid) AND lm.pair_id=lp.pair_id AND lm.seen NOT LIKE '$seen' AND lm.sender_id!=$userid AND lu.id = lm.sender_id GROUP BY lm.pair_id";
	$q1 = "SELECT lu.id,lm.message_id,lm.message,lm.time,lu.name FROM lonelyusers as lu,(SELECT * FROM lonelymessages ORDER BY time DESC) as lm,lonelypairs as lp WHERE (lp.first_user_id=$userid OR lp.second_user_id=$userid) AND lm.pair_id=lp.pair_id AND lm.seen LIKE '$seen' AND lm.sender_id!=$userid AND lu.id = lm.sender_id GROUP BY lm.pair_id";
	$result1=mysqli_query($connection,$q);
	$rows=array();
	while($row=mysqli_fetch_assoc($result1))
		{
			$rows[]=$row;
			$rows[]['new']="true";
		}
	$result2=mysqli_query($connection,$q1);
	while($row=mysqli_fetch_assoc($result2)){
		$rows[]=$row;
		$rows[]['new']="false";
	}
	echo json_encode($rows);
?>
	