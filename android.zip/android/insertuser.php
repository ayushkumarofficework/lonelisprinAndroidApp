<?php
	header('Content-type:application/json');
    $connection = mysqli_connect("localhost", "root" , "","lonelisprin");
	//mysql_select_db("lonelisprin",$connection);
    //$db   = mysql_select_db("lonelisprin");
	$email=$_REQUEST['email'];
		$name=$_REQUEST['name'];
		$password=$_REQUEST['password'];
		str_replace("_"," ",$name);
		str_replace("_"," ",$email);str_replace("_"," ",$password);
		$query="SELECT * FROM lonelyusers WHERE email LIKE '".$email."'";
		$check=mysqli_query($connection,$query);
		$res=mysqli_num_rows($check);
		if($res==0){
			$query="INSERT INTO lonelyusers(name,email,password,lastseen) VALUES('".$name."','".$email."','".$password."','".$_SERVER['REQUEST_TIME']."')";
		mysqli_query($connection,$query) ;
		$query="SELECT * FROM lonelyusers WHERE email LIKE '".$email."'";
		$select=mysqli_query($connection,$query);
		$rows=array();
		while($row=mysqli_fetch_assoc($select))
			{
				$rows[]=$row;
			}
			echo json_encode($rows);
		}
		else{
			//echo "alreadyexists";
			}
		
		//else echo json_encode("false");
?>