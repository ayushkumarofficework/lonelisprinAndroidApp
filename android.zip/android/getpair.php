<?php
	header('Content-type:application/json');
    $connection = mysqli_connect("localhost", "root" , "","lonelisprin");
	$userid=$_REQUEST['user_id'];
	$sessionuserid=$_REQUEST['session_user_id'];
	$query="SELECT * FROM lonelypairs WHERE (first_user_id='".$userid."' AND second_user_id='".$sessionuserid."') OR (first_user_id='".$sessionuserid."' AND second_user_id='".$userid."')";
	$result=mysqli_query($connection,$query);
	$rows=array();
		while($row=mysqli_fetch_assoc($result))
			{
				$rows[]=$row;
			}
	echo json_encode($rows);
?>